#ifdef CONFIG_ARCH_CORTINA

#define CONFIG_RTW_HOSTAPD_ACS
#ifdef CONFIG_RTW_HOSTAPD_ACS
	#define WKARD_ACS /* for compile happy */
#endif /* CONFIG_RTW_HOSTAPD_ACS */

#endif /* CONFIG_ARCH_CORTINA */
