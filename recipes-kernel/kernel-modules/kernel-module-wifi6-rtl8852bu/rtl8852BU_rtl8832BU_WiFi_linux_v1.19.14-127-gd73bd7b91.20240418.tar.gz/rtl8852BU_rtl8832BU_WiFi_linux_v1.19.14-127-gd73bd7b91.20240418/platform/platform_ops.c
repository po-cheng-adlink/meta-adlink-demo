/******************************************************************************
 *
 * Copyright(c) 2013 - 2022 Realtek Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 *****************************************************************************/
#include <drv_types.h>

int platform_wifi_power_on(void)
{
        return 0;
}

void platform_wifi_power_off(void)
{

}

void platform_wifi_get_oob_irq(int *oob_irq)
{

}

void platform_wifi_mac_addr(u8 *mac_addr)
{

}