/******************************************************************************
 *
 * Copyright(c) 2022 Realtek Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 *****************************************************************************/
#ifndef _HAL_FEATURE_H_
#define _HAL_FEATURE_H_

#if defined(PHL_PLATFORM_LINUX)
/*
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_WIFI_SENSING_CSI
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_SCAN_OFFLOAD
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_WRITE_OFFLOAD
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_SWITCH_CHANNEL_OFFLOAD
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_PS_SUPPORT_CPU_PG
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_TWT_NIC
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_NAN
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_FTM
			#error "fw feature unexpected"
		#endif
	#endif
	#ifdef CONFIG_PHL_XXXX
		#ifndef FW_CONFIG_RATE_ADAPTIVE
			#error "fw feature unexpected"
		#endif
	#endif
*/

#endif

#endif /*_HAL_FEATURE_H_*/
